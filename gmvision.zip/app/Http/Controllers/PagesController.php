<?php

namespace App\Http\Controllers;

use App\Models\ActivityVideo;
use Illuminate\Http\Request;
use App\Models\Project;

class PagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function welcome()
    {
        $activity_videos = ActivityVideo::latest()->get();
        return view('welcome')->with('activity_videos', $activity_videos);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function about()
    {
        return view('pages.about');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function gallery()
    {
        return view('pages.gallery');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function contact()
    {
        return view('pages.contact');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function payment()
    {
        $projects = Project::where('status', 'active')->get();
        return view('pages.payment')->with('projects', $projects);
    }

    public function getImages(Request $request){
        $path = public_path($request->folderName);
        $filePath = asset($request->folderName);
        $files = array_diff(scandir($path), array('.', '..'));
        $fileList = [];
        foreach ($files as $file){
            $fileList[] = $filePath.'/'.$file;
        }
        return response()->json($fileList);
    }
}
