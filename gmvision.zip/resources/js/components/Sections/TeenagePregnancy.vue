<template>

</template>

<script>
    export default {
        name: "TeenagePregnancy"
    }
</script>

<style scoped>

</style>
