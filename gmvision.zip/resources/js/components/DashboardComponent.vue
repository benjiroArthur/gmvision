<template>
<div>

</div>
</template>

<script>
    export default {
        name: "DashboardComponent",
        data () {},
        mounted() {
        }
    }
</script>

<style scoped>

</style>
