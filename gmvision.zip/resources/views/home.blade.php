@extends('layouts.app')

@section('content')
    <div class="container">
        <dash-component></dash-component>
    </div>
@endsection
