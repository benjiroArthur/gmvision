@extends('layouts.app')

@section('content')
    <div class="container-fluid pt-10">
        <dash-component></dash-component>
    </div>
@endsection
