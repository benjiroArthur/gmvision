<?php ($routeName = \Route::currentRouteName()); ?>
<div class="site-preloader-wrap">
    <div class="spinner">
        <img src="<?php echo e(asset('img/gm-loader.png')); ?>" style="height: 100px; width: 100px">
    </div>
    
</div><!-- Preloader -->

<header id="header" class="header-section">
    <div class="top-header">
        <div class="container">
            <div class="top-content-wrap row">
                <div class="col-sm-8">
                    <ul class="left-info">
                        <li><a href="#"><i class="ti-email"></i>
                                
                                gmvint@yahoo.com
                            </a></li>
                        <li><a href="#"><i class="ti-mobile"></i>+(233) 0247719755</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 d-none d-md-block">
                    <ul class="right-info">
                        <li><a href="https://www.facebook.com/gmvint/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-header">
        
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="site-branding">
                <a href="#"><img src="<?php echo e(asset('img/gm_logo.png')); ?>" alt="Brand"></a>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul id="mainmenu" class="nav navbar-nav nav-menu ml-auto mr-auto">
                    <?php if(auth()->guard()->check()): ?>
                    <li><a class="nav-link"  style="color: <?php echo e($routeName === 'home' ? '#0b1af8' : ''); ?>" href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <?php endif; ?>
                    <li><a class="nav-link"  style="color: <?php echo e($routeName === 'welcome' ? '#0b1af8' : ''); ?>" href="<?php echo e(route('welcome')); ?>">Home</a></li>
                    <li><a class="nav-link"  style="color: <?php echo e($routeName === 'about' ? '#0b1af8' : ''); ?>" href="<?php echo e(route('about')); ?>">About</a></li>

                   
                        <?php if(auth()->guard()->check()): ?>
                            <li>
                                <a class="nav-link" href="" onclick="preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    Logout</a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                        <?php endif; ?>
                </ul>
                <a href="<?php echo e(url('/payment')); ?>" class="btn btn-primary text-white" style="text-decoration: none">Donate Now</a>
            </div>
        </nav>
    </div>
</header><!-- /Header Section -->
<div class="header-height"></div>
<?php /**PATH C:\xampp\htdocs\gmvision\resources\views/inc/navbar.blade.php ENDPATH**/ ?>