

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center pt-5">
        <div class="col-md-6">
            <form novalidate class="form-control form-style text-center needs-validation" action="<?php echo e(url('/pay')); ?>" method="post" id="payment-form">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control pay-fields" name="last_name" placeholder="Last Name" required>
                            <div class="valid-feedback">
                                looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please choose a last name.
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control pay-fields" name="first_name" placeholder="Other Name(s)" required>
                            <div class="valid-feedback">
                                looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please choose a first name.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <input type="email" class="form-control pay-fields" name="email" placeholder="Email" required>
                    <div class="valid-feedback">
                        looks good!
                    </div>
                    <div class="invalid-feedback">
                        Please choose a valid email.
                    </div>
                </div>
                <div class="form-group">
                    <input type="tel" pattern="[0-9]{3}[0-9]{3}[0-9]{4,9}" class="form-control pay-fields" name="phone" placeholder="Phone Number" required>
                    <div class="valid-feedback">
                        looks good!
                    </div>
                    <div class="invalid-feedback">
                        Please choose a valid phone number.
                    </div>
                </div>
                <div class="form-group">
                    <input type="number"  class="form-control pay-fields" name="amount" placeholder="Amount" required>
                    <div class="valid-feedback">
                        looks good!
                    </div>
                    <div class="invalid-feedback">
                        Please choose a valid amount you want to donate.
                    </div>
                </div>
                <div class="form-group">
                    <select class="form-control pay-fields" name="project_id">
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option>No Projects</option>
                        <?php endif; ?>
                    </select>
                </div>
                

                <button type="submit" class="btn btn-primary text-white" >Proceed To Make Payment</button>
                <p><small>Please note that you will be redirected to a trusted and secured payment platform (Paystack) to make the payment</small></p>
            </form>
        </div>
    </div>
    <br><br>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function isChecked(val){
            let currentValue =  $('input[name = "pay_type"]:checked').val()
            let oneButton = $('#one-button')
            let monthlyButton = $('#monthly-button')
            let oneRadio = $('#one-radio')
            let monthlyRadio = $('#monthly-radio')
            if (val !== currentValue) {
                switch (val) {
                    case 'one':
                        oneButton.toggleClass('btn-primary btn-outline-primary')
                        monthlyButton.toggleClass('btn-primary btn-outline-primary')
                        oneRadio.click()
                        break
                    case 'monthly':
                        oneButton.toggleClass('btn-primary btn-outline-primary')
                        monthlyButton.toggleClass('btn-primary btn-outline-primary')
                        monthlyRadio.click()
                        break
                }
            }
        }
        function submitForm() {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            let forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }

                        form.classList.add('was-validated')
                    }, false)
                })
        }
        $(document).ready(function(){
            submitForm()
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gmvision\resources\views/pages/payment.blade.php ENDPATH**/ ?>